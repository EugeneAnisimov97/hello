from colorama import *
init()
def main():
    print(Fore.RED + "Hello!")


if __name__ == '__main__':
    main()
